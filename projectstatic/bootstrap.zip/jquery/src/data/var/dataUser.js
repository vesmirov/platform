define( [
	"../Data"
], function( Data ) {
	"use strict";

	return new Data();
} );
